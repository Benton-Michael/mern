import React from "react";
// import { NavLink } from "react-router-dom";
import "./Header.css";

function Header() {
  return (
    // html5 header is like a div here
    <header>
      Pet Shelter
    </header>
  );
}

export default Header;
